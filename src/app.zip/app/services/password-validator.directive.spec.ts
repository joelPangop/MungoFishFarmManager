import { PasswordValidatorDirective } from './password-validator.directive';

describe('PasswordValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new PasswordValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
