import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TankProductRoutingModule } from './tank-product-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    TankProductRoutingModule
  ]
})
export class TankProductModule { }
