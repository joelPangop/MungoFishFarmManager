export enum CategoryTelephone {
  MOBILE = 'Mobile',
  HOME = 'Home',
  OFFICE = 'Office'
}
