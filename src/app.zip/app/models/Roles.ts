export enum Roles {
  SUPERADMIN = 'SuperAdmin',
  ADMIN = 'Admin',
  USER = 'User'
}
