export class TankProduct {
  id: number;
  type: string;
  qtyProduct: number;

  constructor() {
    this.id = 0;
    this.type = "";
    this.qtyProduct = 0;
  }
}
