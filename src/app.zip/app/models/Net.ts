import {Tank} from "./Tank";

export class Net {
  tankID!: number;
  numNet: number;

  constructor() {
    this.numNet = 0;
  }
}
