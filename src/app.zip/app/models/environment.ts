export const environment = {
  api_url: "https://mungofishfarmservices.herokuapp.com"
// api_url : 'http://localhost:3000'
}
