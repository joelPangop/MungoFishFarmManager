export class Role {
  id?: number;
  roleName?: string;

  constructor() {
  }
}
