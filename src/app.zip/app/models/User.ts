export class User {
  id?: number;
  userName: string;
  email: string;
  password?: string;
  userInfoID?: number;
  roleID?: number;

  constructor() {
    this.userName = '';
    this.email = '';
    this.roleID = 3;
  }
}
